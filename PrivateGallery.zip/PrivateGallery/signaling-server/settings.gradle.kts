rootProject.name = "signaling-server"
